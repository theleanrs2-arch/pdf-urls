#!/usr/bin/env python3
"""
Unified startup script to run both FastAPI backend and the React frontend.
"""
import subprocess
import sys
import os
import time
import signal
from pathlib import Path

# Change to project root directory
project_root = Path(__file__).parent
os.chdir(project_root)

def run_backend():
    """Run FastAPI backend server."""
    print("🚀 Starting FastAPI backend on http://localhost:8008")
    return subprocess.Popen(
        [sys.executable, "run.py"],
        cwd=project_root
    )

def run_frontend():
    """Run React (Vite) frontend dev server."""
    print("🎨 Starting React frontend on http://localhost:5173")
    frontend_dir = project_root / "frontend"
    npm_cmd = "npm.cmd" if os.name == "nt" else "npm"
    env = os.environ.copy()
    try:
        return subprocess.Popen(
            [npm_cmd, "run", "dev", "--", "--host"],
            cwd=frontend_dir,
            env=env,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("npm was not found in PATH. Install Node.js 18+ to run the frontend.") from exc

def main():
    """Main function to start both services."""
    print("=" * 60)
    print("IR-FETCHER - Starting Backend and Frontend")
    print("=" * 60)
    print()
    
    processes = []
    
    try:
        # Start backend
        backend_process = run_backend()
        processes.append(backend_process)
        time.sleep(2)  # Give backend time to start
        
        # Start frontend
        frontend_process = run_frontend()
        processes.append(frontend_process)
        
        print()
        print("=" * 60)
        print("✅ Both services are running!")
        print("=" * 60)
        print("📡 Backend API: http://localhost:8008")
        print("📡 API Docs: http://localhost:8008/docs")
        print("🎨 Frontend: http://localhost:5173")
        print()
        print("Press Ctrl+C to stop all services")
        print("=" * 60)
        print()
        
        # Wait for processes
        while True:
            time.sleep(1)
            # Check if any process has died
            for proc in processes:
                if proc.poll() is not None:
                    print(f"⚠️  Process {proc.pid} has stopped unexpectedly")
                    raise KeyboardInterrupt
    
    except KeyboardInterrupt:
        print("\n🛑 Shutting down services...")
        for proc in processes:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            except Exception as e:
                print(f"Error stopping process: {e}")
        print("✅ All services stopped")
        sys.exit(0)

if __name__ == "__main__":
    main()

