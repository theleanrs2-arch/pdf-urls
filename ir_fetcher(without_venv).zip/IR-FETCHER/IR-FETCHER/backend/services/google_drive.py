import asyncio
import io
import json
import logging
import os
from threading import Lock
from typing import Dict, Optional

logger = logging.getLogger(__name__)

SCOPES = ["https://www.googleapis.com/auth/drive.file"]
SERVICE_ACCOUNT_FILE = os.getenv("GOOGLE_DRIVE_SERVICE_ACCOUNT_FILE")
SERVICE_ACCOUNT_JSON = os.getenv("GOOGLE_DRIVE_SERVICE_ACCOUNT_JSON")
DEFAULT_FOLDER_ID = os.getenv("GOOGLE_DRIVE_FOLDER_ID")
SHARE_WITH_ANYONE = os.getenv("GOOGLE_DRIVE_SHARE_WITH_ANYONE", "true").lower() in {
    "1",
    "true",
    "yes",
}

try:  # pragma: no cover - imported lazily for optional dependency
    from google.oauth2.service_account import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    from googleapiclient.http import MediaIoBaseUpload
except Exception:  # pragma: no cover
    Credentials = None
    build = None
    HttpError = Exception
    MediaIoBaseUpload = None

_service = None
_service_lock = Lock()


def _ensure_dependencies():
    if Credentials is None or build is None or MediaIoBaseUpload is None:
        raise ImportError(
            "google-api-python-client is required for Google Drive uploads. "
            "Install google-api-python-client and google-auth."
        )
    if not (SERVICE_ACCOUNT_FILE or SERVICE_ACCOUNT_JSON):
        raise RuntimeError(
            "Google Drive credentials not configured. "
            "Set GOOGLE_DRIVE_SERVICE_ACCOUNT_FILE or GOOGLE_DRIVE_SERVICE_ACCOUNT_JSON."
        )


def _build_credentials():
    if SERVICE_ACCOUNT_JSON:
        info = json.loads(SERVICE_ACCOUNT_JSON)
        return Credentials.from_service_account_info(info, scopes=SCOPES)
    return Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)


def _get_service():
    global _service
    if _service is not None:
        return _service

    with _service_lock:
        if _service is None:
            creds = _build_credentials()
            _service = build("drive", "v3", credentials=creds, cache_discovery=False)
    return _service


def _construct_links(file_id: str, web_view: Optional[str], web_content: Optional[str]) -> Dict[str, str]:
    view_link = web_view or f"https://drive.google.com/file/d/{file_id}/view?usp=drive_web"
    download_link = (
        web_content or f"https://drive.google.com/uc?id={file_id}&export=download"
    )
    return {"view_link": view_link, "download_link": download_link}


def _upload_blocking(filename: str, data: bytes, mimetype: Optional[str], folder_id: Optional[str]) -> Dict[str, str]:
    _ensure_dependencies()
    service = _get_service()
    media = MediaIoBaseUpload(io.BytesIO(data), mimetype=mimetype or "application/pdf", resumable=False)
    body = {
        "name": filename,
        "mimeType": mimetype or "application/pdf",
    }
    if folder_id or DEFAULT_FOLDER_ID:
        body["parents"] = [folder_id or DEFAULT_FOLDER_ID]

    created = (
        service.files()
        .create(body=body, media_body=media, fields="id, name, webViewLink, webContentLink")
        .execute()
    )
    file_id = created["id"]

    if SHARE_WITH_ANYONE:
        try:
            service.permissions().create(
                fileId=file_id,
                body={"type": "anyone", "role": "reader"},
                fields="id",
            ).execute()
        except HttpError as exc:  # pragma: no cover - best effort
            logger.warning("Unable to set public permission on %s: %s", file_id, exc)

    links = _construct_links(file_id, created.get("webViewLink"), created.get("webContentLink"))
    return {
        "id": file_id,
        "name": created.get("name", filename),
        "view_link": links["view_link"],
        "download_link": links["download_link"],
    }


async def upload_bytes_to_drive(
    filename: str,
    data: bytes,
    mimetype: Optional[str] = None,
    folder_id: Optional[str] = None,
) -> Dict[str, str]:
    """
    Upload a blob to Google Drive returning identifiers and shareable links.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, lambda: _upload_blocking(filename, data, mimetype, folder_id)
    )

