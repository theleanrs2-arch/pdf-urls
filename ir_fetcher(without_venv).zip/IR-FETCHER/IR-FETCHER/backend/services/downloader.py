import hashlib
import logging
import mimetypes
from typing import Optional

from ..agents.naming import build_path
from ..models import DownloadedFile, FoundFile
from ..util.http import get_bytes
from .google_drive import upload_bytes_to_drive

logger = logging.getLogger(__name__)

def _ext_from_mime(mt: Optional[str]) -> str:
    if not mt:
        return ".bin"
    guess = mimetypes.guess_extension(mt.split(";")[0].strip())
    return guess or ".bin"

async def download_one(company: str, doc_type: str, year: Optional[int], f: FoundFile) -> Optional[DownloadedFile]:
    try:
        logger.info(f"Downloading {f.url} for {company} {doc_type} {year}")
        data, mime = await get_bytes(f.url)
        sha256 = hashlib.sha256(data).hexdigest()
        ext = _ext_from_mime(mime)
        _, filename = build_path(company, doc_type, year, ext)
        upload = await upload_bytes_to_drive(filename, data, mime)
        storage_url = upload.get("view_link")
        logger.info(f"Uploaded file {filename} to Google Drive ({upload['id']})")
        return DownloadedFile(
            company=company, doc_type=doc_type, year=year,
            file_path=storage_url,
            filename=upload.get("name", filename),
            url=f.url,
            sha256=sha256,
            mimetype=mime or "",
            source=f.source,
            drive_file_id=upload["id"],
            drive_view_link=upload.get("view_link"),
            drive_download_link=upload.get("download_link"),
        )
    except Exception as e:
        logger.error(f"Failed to download {f.url}: {str(e)}", exc_info=True)
        return None
