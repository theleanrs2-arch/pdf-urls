import React from 'react'

interface ErrorAlertProps {
  message: string
  onClose: () => void
}

export const ErrorAlert: React.FC<ErrorAlertProps> = ({ message, onClose }) => {
  return (
    <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex justify-between items-start">
      <div>
        <h3 className="font-semibold text-red-900">Error</h3>
        <p className="text-red-700 text-sm mt-1">{message}</p>
      </div>
      <button
        onClick={onClose}
        className="text-red-600 hover:text-red-800 font-bold"
      >
        ×
      </button>
    </div>
  )
}
