import React from 'react'
import { DownloadedFile } from '../services/api'

interface ResultsTableProps {
  results: DownloadedFile[]
  showJson: boolean
  onToggleJson: () => void
}

export const ResultsTable: React.FC<ResultsTableProps> = ({ results, showJson, onToggleJson }) => {
  if (results.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No results found. Try a different search.
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Results ({results.length})</h2>
        <button
          onClick={onToggleJson}
          className="px-3 py-1 text-sm bg-gray-200 hover:bg-gray-300 rounded transition-colors"
        >
          {showJson ? 'Table View' : 'JSON View'}
        </button>
      </div>

      {showJson ? (
        <div className="bg-gray-100 p-4 rounded-lg overflow-auto max-h-96">
          <pre className="text-sm font-mono whitespace-pre-wrap break-words">
            {JSON.stringify(results, null, 2)}
          </pre>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-gray-300">
            <thead className="bg-gray-100">
              <tr>
                <th className="border border-gray-300 px-4 py-2 text-left">Company</th>
                <th className="border border-gray-300 px-4 py-2 text-left">Report Type</th>
                <th className="border border-gray-300 px-4 py-2 text-left">Year</th>
                <th className="border border-gray-300 px-4 py-2 text-left">Stored File</th>
                <th className="border border-gray-300 px-4 py-2 text-left">Source URL</th>
                <th className="border border-gray-300 px-4 py-2 text-left">MIME</th>
                <th className="border border-gray-300 px-4 py-2 text-left">Source</th>
              </tr>
            </thead>
            <tbody>
              {results.map((result, idx) => (
                <tr key={idx} className="hover:bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">{result.company}</td>
                  <td className="border border-gray-300 px-4 py-2 capitalize">{result.doc_type}</td>
                  <td className="border border-gray-300 px-4 py-2">{result.year ?? '—'}</td>
                  <td className="border border-gray-300 px-4 py-2">
                    <a
                      href={result.drive_view_link || result.file_path}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline truncate block"
                      title={result.drive_view_link || result.file_path}
                    >
                      {result.filename || 'View in Drive'}
                    </a>
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <a
                      href={result.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-sm truncate block"
                      title={result.url}
                    >
                      Source
                    </a>
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-sm">{result.mimetype || 'Unknown'}</td>
                  <td className="border border-gray-300 px-4 py-2 text-sm">{result.source || 'N/A'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
