import React from 'react'
import { DownloadedFile } from '../services/api'

interface StatsDisplayProps {
  results: DownloadedFile[]
}

export const StatsDisplay: React.FC<StatsDisplayProps> = ({ results }) => {
  const uniqueYears = Array.from(new Set(results.map((r) => r.year).filter(Boolean))) as number[]
  const uniqueDocTypes = Array.from(new Set(results.map((r) => r.doc_type)))
  const sources = Array.from(new Set(results.map((r) => r.source))).filter(Boolean)

  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="text-green-600 text-sm">Documents Stored</div>
        <div className="text-2xl font-bold text-green-900">{results.length}</div>
      </div>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="text-blue-600 text-sm">Years Covered</div>
        <div className="text-2xl font-bold text-blue-900">{uniqueYears.length || 'N/A'}</div>
      </div>
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
        <div className="text-purple-600 text-sm">Document Types</div>
        <div className="text-2xl font-bold text-purple-900">{uniqueDocTypes.length || 'N/A'}</div>
      </div>
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
        <div className="text-orange-600 text-sm">Sources</div>
        <div className="text-2xl font-bold text-orange-900">{sources.length || 'N/A'}</div>
      </div>
    </div>
  )
}
