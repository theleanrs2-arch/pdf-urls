import React, { useEffect, useState } from 'react'
import { fetchSettingsStatus, updateSettings, SettingsUpdatePayload, SettingsStatus } from '../services/api'

interface SettingsModalProps {
  isOpen: boolean
  onClose: () => void
}

const EMPTY_FORM: SettingsUpdatePayload = {
  openai_api_key: '',
  tavily_api_key: '',
  google_api_key: '',
  google_cse_id: '',
  default_provider: '',
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [status, setStatus] = useState<SettingsStatus | null>(null)
  const [formState, setFormState] = useState<SettingsUpdatePayload>({ ...EMPTY_FORM })
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [messageType, setMessageType] = useState<'success' | 'error'>('success')

  useEffect(() => {
    if (isOpen) {
      loadStatus()
    }
  }, [isOpen])

  const loadStatus = async () => {
    setIsLoading(true)
    setMessage(null)
    try {
      const result = await fetchSettingsStatus()
      setStatus(result)
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load settings.'
      setMessageType('error')
      setMessage(msg)
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (field: keyof SettingsUpdatePayload, value: string) => {
    setFormState((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const payload: SettingsUpdatePayload = {}
    Object.entries(formState).forEach(([key, value]) => {
      if (value && value.trim().length > 0) {
        payload[key as keyof SettingsUpdatePayload] = value.trim()
      }
    })

    if (Object.keys(payload).length === 0) {
      setMessageType('error')
      setMessage('Enter at least one value to update.')
      return
    }

    setIsSaving(true)
    setMessage(null)

    try {
      const response = await updateSettings(payload)
      setMessageType('success')
      setMessage(`Updated: ${response.updated.join(', ') || 'no changes applied'}`)
      setFormState({ ...EMPTY_FORM })
      await loadStatus()
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to update settings.'
      setMessageType('error')
      setMessage(msg)
    } finally {
      setIsSaving(false)
    }
  }

  if (!isOpen) {
    return null
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
          aria-label="Close settings"
        >
          ×
        </button>
        <h2 className="text-2xl font-semibold mb-4">API & Storage Settings</h2>

        {isLoading ? (
          <p className="text-sm text-gray-500">Loading current status...</p>
        ) : (
          status && (
            <div className="bg-gray-50 rounded-lg p-3 text-sm mb-4">
              <p className="font-medium mb-2 text-gray-700">Current Values (masked)</p>
              <div className="grid grid-cols-2 gap-2 text-gray-600">
                {Object.entries(status).map(([key, value]) => (
                  <div key={key} className="flex justify-between">
                    <span>{key}</span>
                    <span>{value ?? '—'}</span>
                  </div>
                ))}
              </div>
            </div>
          )
        )}

        {message && (
          <div
            className={`mb-4 rounded-lg p-3 text-sm ${
              messageType === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
            }`}
          >
            {message}
          </div>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">OpenAI API Key</label>
            <input
              type="password"
              className="w-full border rounded-lg px-3 py-2"
              value={formState.openai_api_key}
              onChange={(e) => handleChange('openai_api_key', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tavily API Key</label>
            <input
              type="password"
              className="w-full border rounded-lg px-3 py-2"
              value={formState.tavily_api_key}
              onChange={(e) => handleChange('tavily_api_key', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Google API Key</label>
            <input
              type="password"
              className="w-full border rounded-lg px-3 py-2"
              value={formState.google_api_key}
              onChange={(e) => handleChange('google_api_key', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Google CSE ID</label>
            <input
              type="password"
              className="w-full border rounded-lg px-3 py-2"
              value={formState.google_cse_id}
              onChange={(e) => handleChange('google_cse_id', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Default Provider</label>
            <select
              className="w-full border rounded-lg px-3 py-2"
              value={formState.default_provider}
              onChange={(e) => handleChange('default_provider', e.target.value)}
            >
              <option value="">Use backend default</option>
              <option value="openai">OpenAI</option>
              <option value="gemini">Gemini</option>
            </select>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                setFormState({ ...EMPTY_FORM })
                setMessage(null)
              }}
              className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100"
              disabled={isSaving}
            >
              Reset
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:bg-gray-400"
              disabled={isSaving}
            >
              {isSaving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
