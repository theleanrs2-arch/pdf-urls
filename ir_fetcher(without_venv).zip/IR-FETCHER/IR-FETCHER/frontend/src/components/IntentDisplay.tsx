import React from 'react'
import { IntentPayload } from '../services/api'

interface IntentDisplayProps {
  intent: IntentPayload
}

export const IntentDisplay: React.FC<IntentDisplayProps> = ({ intent }) => {
  const ticker = intent.extras?.ticker || intent.extras?.parsed_company

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
      <h3 className="font-semibold text-blue-900">Intent Summary</h3>
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <span className="font-medium">Company:</span> {intent.company}
          {ticker && <span className="text-gray-600"> ({ticker})</span>}
        </div>
        <div>
          <span className="font-medium">Document Type:</span> {intent.doc_type}
        </div>
        <div>
          <span className="font-medium">Years:</span> {intent.years.length ? intent.years.join(', ') : 'Not specified'}
        </div>
        {intent.region && (
          <div>
            <span className="font-medium">Region:</span> {intent.region}
          </div>
        )}
      </div>
    </div>
  )
}
