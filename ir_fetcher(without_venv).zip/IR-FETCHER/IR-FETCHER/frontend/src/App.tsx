import React, { useState } from 'react'
import { SearchForm } from './components/SearchForm'
import { ResultsTable } from './components/ResultsTable'
import { IntentDisplay } from './components/IntentDisplay'
import { StatsDisplay } from './components/StatsDisplay'
import { ErrorAlert } from './components/ErrorAlert'
import { SettingsModal } from './components/SettingsModal'
import { requestDocuments, IntentPayload, DownloadedFile } from './services/api'

function App() {
  const [intent, setIntent] = useState<IntentPayload | null>(null)
  const [results, setResults] = useState<DownloadedFile[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showJson, setShowJson] = useState(false)
  const [showSettings, setShowSettings] = useState(false)

  const handleSearch = async (prompt: string, ticker?: string) => {
    setIsLoading(true)
    setError(null)
    setIntent(null)
    setResults([])

    try {
      const response = await requestDocuments({
        prompt,
        ticker: ticker || undefined,
        prefer_official: true,
      })
      setIntent(response.intent)
      setResults(response.results)
      if (response.results.length === 0) {
        setError('No documents were found for this query.')
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred while searching'
      setError(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">IR PDF Finder</h1>
            <p className="text-gray-600">Find and retrieve URLs of financial PDF documents</p>
          </div>
          <button
            onClick={() => setShowSettings(true)}
            className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors flex items-center gap-2"
            title="API Settings"
          >
            <span>⚙️</span>
            <span className="hidden sm:inline">Settings</span>
          </button>
        </div>

        {/* Search Form */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <SearchForm onSearch={handleSearch} isLoading={isLoading} />
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-8">
            <ErrorAlert message={error} onClose={() => setError(null)} />
          </div>
        )}

        {/* Intent Section */}
        {intent && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <IntentDisplay intent={intent} />
          </div>
        )}

        {/* Stats Section */}
        {results.length > 0 && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <StatsDisplay results={results} />
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <ResultsTable results={results} showJson={showJson} onToggleJson={() => setShowJson(!showJson)} />
            </div>
          </div>
        )}

        {/* Empty State */}
        {!intent && results.length === 0 && !isLoading && (
          <div className="text-center py-12 text-gray-500">
            <p className="text-lg">Enter a search query to find PDF documents</p>
            <p className="text-sm mt-2">Example: "Download annual reports from 2020 to 2024"</p>
          </div>
        )}

        {/* Settings Modal */}
        <SettingsModal isOpen={showSettings} onClose={() => setShowSettings(false)} />
      </div>
    </div>
  )
}

export default App
