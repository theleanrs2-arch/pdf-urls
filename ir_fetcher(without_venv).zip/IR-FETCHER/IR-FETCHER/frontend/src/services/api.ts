import axios from 'axios'

const rawBase = import.meta.env.VITE_API_BASE_URL
const API_BASE_URL =
  rawBase && rawBase.trim().length > 0
    ? rawBase.replace(/\/$/, '')
    : 'http://localhost:8008'

export interface IntentPayload {
  company: string
  doc_type: string
  years: number[]
  region?: string | null
  doc_types: string[]
  extras: Record<string, string>
}

export interface DownloadedFile {
  company: string
  doc_type: string
  year?: number | null
  file_path: string
  filename: string
  url: string
  sha256: string
  mimetype: string
  source: string
  drive_file_id?: string | null
  drive_view_link?: string | null
  drive_download_link?: string | null
}

export interface DownloadResponse {
  intent: IntentPayload
  results: DownloadedFile[]
}

export interface DownloadRequest {
  prompt: string
  ticker?: string
  prefer_official?: boolean
  max_items?: number
  year_window?: number
}

export type SettingsStatus = Record<string, string | null>

export interface SettingsUpdatePayload {
  openai_api_key?: string
  tavily_api_key?: string
  google_api_key?: string
  google_cse_id?: string
  default_provider?: string
}

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 120000,
})

export const requestDocuments = async (payload: DownloadRequest): Promise<DownloadResponse> => {
  const response = await apiClient.post<DownloadResponse>('/download', payload)
  return response.data
}

export const fetchSettingsStatus = async (): Promise<SettingsStatus> => {
  const response = await apiClient.get<SettingsStatus>('/settings')
  return response.data
}

export const updateSettings = async (payload: SettingsUpdatePayload) => {
  const response = await apiClient.post<{ updated: string[] }>('/settings', payload)
  return response.data
}

export default apiClient
