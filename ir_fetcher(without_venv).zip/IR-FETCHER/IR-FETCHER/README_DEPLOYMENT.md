# Deployment Guide

This guide covers deploying IR-FETCHER to Vercel and setting up the database.

## Prerequisites

1. Node.js 18+ installed
2. Python 3.8+ installed
3. Vercel account (free tier works)
4. Database (SQLite for local, Supabase for deployment)

## Quick Start - Local Development

### Option 1: Run Everything with One Command

```bash
# Windows
start_all.bat

# Linux/Mac
python start_all.py
```

This will start:
- FastAPI backend on http://localhost:8008
- React frontend (Vite dev server) on http://localhost:5173

### Option 2: Run Separately

```bash
# Terminal 1: Backend
python run.py

# Terminal 2: Frontend (React)
cd frontend
npm install
npm run dev -- --host
```

## Database Setup

### SQLite (Default - No Setup Required)

SQLite is used by default. The database file will be created automatically at `./data/database.db` on first run.

### Supabase (Deployment)

1. Create a Supabase project (https://supabase.com) – the free tier works.
2. In the SQL editor, create a `files` table (or reuse an existing one) with columns that match the metadata schema (`company`, `doc_type`, `year`, `file_path`, `filename`, `url`, `sha256`, `mimetype`, `source`, `indexed_at`, `created_at`).
3. Grab the project `SUPABASE_URL` and the **service role** key from Project Settings → API.
4. Set the following environment variables in your deployment target:
   ```
   DATABASE_BACKEND=supabase
   SUPABASE_URL=https://your-project.supabase.co
   SUPABASE_SERVICE_ROLE_KEY=service_role_key_here
   SUPABASE_TABLE=files   # optional if you used a different table name
   ```

When `DATABASE_BACKEND` is set to `supabase`, all reads/writes go through Supabase.

## Vercel Deployment

### Step 1: Deploy FastAPI Backend

You have two options:

#### Option A: Deploy Backend Separately (Recommended)

Deploy the FastAPI backend to a service that supports Python:
- **Railway**: https://railway.app
- **Render**: https://render.com
- **Fly.io**: https://fly.io
- **Heroku**: https://heroku.com

1. Push your code to GitHub
2. Connect your repository to the service
3. Set environment variables:
   - `OPENAI_API_KEY`
   - `TAVILY_API_KEY`
   - `DATABASE_BACKEND` (set to `supabase` in deployment)
   - `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_TABLE` (if using Supabase)
4. Deploy

#### Option B: Use Vercel Static Hosting + Proxy Routes

You can deploy the React frontend to Vercel (or Netlify, Cloudflare Pages, etc.) and point it to the publicly reachable backend.

### Step 2: Deploy React Frontend to Vercel

1. **Install dependencies & build**
   ```bash
   cd frontend
   npm install
   npm run build
   ```

2. **Deploy via Vercel CLI (or dashboard)**
   ```bash
   vercel --prod
   ```
   - Project root: `frontend`
   - Build command: `npm run build`
   - Output directory: `dist`

3. **Set environment variables in Vercel**
   - `VITE_API_BASE_URL`: URL of the deployed backend (e.g., `https://your-backend.example.com`)

### Step 3: Configure CORS (if needed)

If your backend is on a different domain, update `backend/main.py` to allow CORS:

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## Environment Variables

### Backend (.env file)

```env
# API Keys
OPENAI_API_KEY=your_openai_key
TAVILY_API_KEY=your_tavily_key

# Storage
METADATA_ROOT=./data/metadata
GOOGLE_DRIVE_SERVICE_ACCOUNT_FILE=/path/to/service_account.json
# or set GOOGLE_DRIVE_SERVICE_ACCOUNT_JSON with the raw JSON
GOOGLE_DRIVE_FOLDER_ID=optional_drive_folder_id
GOOGLE_DRIVE_SHARE_WITH_ANYONE=true

# Database selection
DATABASE_BACKEND=sqlite          # or "supabase"
SQLITE_PATH=./data/database.db   # optional override

# Supabase (required if DATABASE_BACKEND=supabase)
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=service_role_key_here
SUPABASE_TABLE=files
```

### Frontend (Vite Environment Variables)

```
VITE_API_BASE_URL=https://your-backend-url.com
```

## Project Structure

```
IR-FETCHER/
├── backend/              # FastAPI backend
│   ├── main.py          # FastAPI app
│   ├── database.py      # Database models
│   └── ...
├── frontend/            # React (Vite) frontend
│   ├── src/
│   ├── index.html
│   └── package.json
├── start_all.py        # Unified startup script
└── vercel.json         # (legacy) Vercel configuration
```

## Troubleshooting

### Database Issues

- **SQLite locked**: Make sure only one process is accessing the database
- **Supabase connection failed**: Verify `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`

### Vercel Deployment Issues

- **API proxy not working**: Check that `BACKEND_URL` is set correctly
- **CORS errors**: Update CORS settings in `backend/main.py`
- **Build fails**: Make sure all dependencies are in `package.json`

### Backend Not Starting

- Check that port 8008 is not in use
- Verify all environment variables are set
- Check logs for errors

## Production Checklist

- [ ] Set up Supabase project/table
- [ ] Configure environment variables
- [ ] Deploy backend to Railway/Render/Fly.io
- [ ] Deploy frontend to Vercel
- [ ] Configure CORS properly
- [ ] Set up monitoring/logging
- [ ] Configure custom domain (optional)
- [ ] Set up SSL certificates (automatic on Vercel)

## Support

For issues or questions, check the main README or open an issue on GitHub.

